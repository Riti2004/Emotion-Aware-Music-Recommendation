import { useState } from 'react';

export default function Home() {
  const [input, setInput] = useState('');
  const [emotion, setEmotion] = useState('');
  const [playlist, setPlaylist] = useState('');

  const playlists: Record<string, string> = {
    Happy: "https://open.spotify.com/playlist/happy123",
    Sad: "https://youtube.com/playlist/sad123",
    Angry: "https://open.spotify.com/playlist/angry123",
    Anxious: "https://youtube.com/playlist/anxious123",
    Relaxed: "https://open.spotify.com/playlist/relaxed123"
  };

  const getEmotion = async () => {
    const res = await fetch('/api/predict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: input })
    });
    const data = await res.json();
    setEmotion(data.emotion);
    setPlaylist(playlists[data.emotion] || '');
  };

  return (
    <main style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Emotion Aware Music App</h1>
      <input
        type="text"
        value={input}
        placeholder="How are you feeling today?"
        onChange={(e) => setInput(e.target.value)}
        style={{ padding: '0.5rem', width: '300px' }}
      />
      <button onClick={getEmotion} style={{ marginLeft: '1rem', padding: '0.5rem 1rem' }}>
        Submit
      </button>
      {emotion && (
        <div style={{ marginTop: '2rem' }}>
          <h2>Your Mood: {emotion}</h2>
          <a href={playlist} target="_blank" rel="noopener noreferrer">🎵 Listen to Playlist</a>
        </div>
      )}
    </main>
  );
}
