import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { text } = req.body;

  const hfResponse = await fetch('https://api-inference.huggingface.co/models/YOUR_USERNAME/YOUR_MODEL_NAME', {
    method: 'POST',
    headers: {
      Authorization: 'Bearer YOUR_HUGGINGFACE_API_KEY',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ inputs: text })
  });

  const result = await hfResponse.json();
  const label = result?.[0]?.label || 'Unknown';

  res.status(200).json({ emotion: label });
}
